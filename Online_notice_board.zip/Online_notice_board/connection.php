<?php
$dbhost='localhost';
$dbname='online_notice';
$dbusername='root';
$dbpass='';
$conn=mysqli_connect($dbhost,$dbusername,$dbpass,$dbname);
?>
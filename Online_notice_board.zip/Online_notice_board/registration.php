<?php 
include("connection.php");
//extract($_POST);
if(isset($_POST['submit']))
{
//check user alereay exists or not
//$sql=mysqli_query($conn,"select * from user where email='$Email'");

//$r=mysqli_num_rows($sql);

//if($r==true)
//{
//$err= "<font color='red'>This user already exists</font>";
//}
//else
//{
//dob
//$dob=$yy."-".$mm."-".$dd;

//hobbies
//$hob=implode(",",$hob);

//image
//$imageName=$_FILES['img']['name'];


//encrypt your password
//$pass=md5($pass);
$id =$_POST['id'];
$Name = $_POST['Name'];
$email = $_POST['email'];
$Pass = $_POST['Pass'];
$Mobile = $_POST['Mobile'];
$Gender=$_POST['Gender'];
//$hob =$_POST['hob'];
//$imageName=$_POST['imageName'];
//$dob=$_POST['dob'];

$query = "INSERT INTO user values('$id','$Name','$email','$Pass','$Mobile','$Gender')";
mysqli_query($conn,$query);

//upload image
if($query)
{
	echo $err="<font color='blue'>Registration successfull !!</font>";
	
}
else
{
	echo "failed";
}
//mkdir("images/$email");
//move_uploaded_file($_FILES['img']['tmp_name'],"images/$email/".$_FILES['img']['name']);


//$err="<font color='blue'>Registration successfull !!</font>";

}





?>

<html>
<h2>Registration Form</h2>
		<form method="post" enctype="multipart/form-data">
			<table class="table table-bordered">
	<Tr>
		<Td colspan="2"><?php echo @$err;?></Td>
	</Tr>
	<tr>
					<td>Enter Your Roll No.</td>
					<Td><input  type="number"  class="form-control" name="id" required/></td>
				</tr>
				
				<tr>
					<td>Enter Your Name</td>
					<Td><input  type="text"  class="form-control" name="Name" required/></td>
				</tr>
				<tr>
					<td>Enter Your Email </td>
					<Td><input type="email"  class="form-control" name="email" required/></td>
				</tr>
				
				<tr>
					<td>Enter Your Password </td>
					<Td><input type="password"  class="form-control" name="Pass" required/></td>
				</tr>
				
				<tr>
					<td>Enter Your Mobile </td>
					<Td><input  class="form-control" type="number" name="Mobile" required/></td>
				</tr>
				
								<tr>
					<td>Select Your Gender</td>
					<Td>
				Male<input type="radio" name="Gender" value="m" required/>
				Female<input type="radio" name="Gender" value="f"/>	
					</td>
				</tr>	
				
					
<Td colspan="2" align="center">
<input type="submit" class="btn btn-success" value="submit" name="submit"/>
<input type="reset" class="btn btn-success" value="Reset"/>
				
					</td>
				</tr>
			</table>
		</form>
	</body>
</html>